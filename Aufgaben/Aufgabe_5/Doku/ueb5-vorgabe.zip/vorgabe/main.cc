#include <iostream>
#include <iterator>
#include <vector>

#include "parser.h"

using namespace std;

int main(int argc, char **argv) {
  vector<Parser::value_type> numbers;
  unique_ptr<Parser> parser;

  if (argc > 1)
    parser = make_unique<Parser>(argv[1]);
  else
    parser = make_unique<Parser>();

  if (!parser || !*parser) {
    cerr << "Cannot create parser for ";
    if (argc > 1)
      cerr << argv[1];
    else
      cerr << "standard input";
    cerr << endl;
    return 1;
  }

  parser->getValues(back_inserter(numbers));

  cout << "found " << numbers.size() << " values:" << endl;
  copy(numbers.begin(), numbers.end(),
       ostream_iterator<decltype(numbers)::value_type>(cout, "\n"));

  return 0;
}
