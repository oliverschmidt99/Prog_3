#include <cstdint>
#include <iostream>
#include <iterator>
#include <fstream>
#include <string>
#include <memory>

/**
 * A parser object is created to read either from cin or from a
 * file. The method good() can be used to check if the associated
 * stream object is still good for reading.  In case the specified
 * file could not be opened or any error condition appeared while
 * reading, good() also returns false.
 */
class Parser {
public:
  typedef int32_t value_type;

  /**
   * Creates parser to read from `cin`.
   */
  Parser(void);

  /**
   * Creates parser to read from given @p filename.
   *
   * @param[in] filename The filename to open.
   */
  Parser(const std::string &filename);

  /**
   * Retrieves all values from the associated input stream and copies
   * them to the specified insert iterator @p out.
   *
   * @param[out] out The insert iterator to fill with the read values.
   */
  template <class OutputIterator>
  void getValues(OutputIterator out);

  /**
   * Returns the parser state. This function returns @c true when the
   * associated stream object is valid and did not yield an error,
   * and @c false otherwise.
   *
   * @result @c true if this object is ready to read another value.
   */
  bool good(void) const;

  /**
   * Invokes good().
   */
  explicit operator bool(void) const { return good(); }
private:
  /**
   * The field input is only for input file streams that we have
   * opened ourselves. Otherwise, we would close foreign stream
   * objects when this object is finalized. */
  std::unique_ptr<std::ifstream> input;

  bool getNext(value_type &value);
};
