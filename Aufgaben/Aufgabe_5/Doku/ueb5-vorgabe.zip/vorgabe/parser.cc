#include "parser.h"

using namespace std;

Parser::Parser(void) {
}

Parser::Parser(const std::string &filename) {
  /* Create ifstream object after the Parser object is completely
   * initialized because we are not sure if this could result in an
   * exception. */
  input = make_unique<ifstream>(filename);
}

bool Parser::good(void) const {
  return input ? input->good() : cin.good();
}

bool Parser::getNext(Parser::value_type &value) {
  if (good()) {
    if (input) {
      return ((*input) >> value).good();
    } else {
      return (cin >> value).good();
    }
  }
  return false;
}
